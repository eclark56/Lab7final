package edu.cscc;

import java.util.Scanner;

public class Main {
    /**
     * @author Ethan Clark CSCI 2467 1-4:20pm Th
     */
    private static Scanner input = new Scanner(System.in);

    /**
     * Who won? the computer or the user (of course after assignment of picks for both the user and computer
     * @param args the actual lines of code to generate and run the game
     */
    public static void main(String[] args) {
        String h_pick;
        String c_pick;
        String answer;
        boolean isValid;

        do {
            System.out.println("Let's play rock, paper, scissors, lizard, spock");
            do {
                System.out.print("Enter your choice: ");
                h_pick = input.nextLine();
                isValid = RPSLSpock.isValidPick(h_pick);
                if (!isValid) {
                    System.out.println(h_pick + " is not a valid choice");
                }
            } while (!isValid);

            c_pick = RPSLSpock.generatePick();
            System.out.print("Computer picked " + c_pick + "  ");

            if (c_pick.equalsIgnoreCase(h_pick)) {
                System.out.println("Tie!");
            } else if (RPSLSpock.isComputerWin(c_pick, h_pick)) {
                System.out.println("Computer wins!");
            } else {
                System.out.println("You win!");
            }

            System.out.print("Play again ('y' or 'n'): ");
            answer = input.nextLine();
        } while ("Y".equalsIgnoreCase(answer));
        System.out.println("Live long and prosper!");
    }

}
/**
 * @param h_pick the user's choice
 * @param c_pick the computer's choice
 * @param answer the result of the round
 * @return A main method to compare and verify that the picks are correct, whether generated or user given; Also, execute a function for who won or if it was a tie.
 *
 */